sizze= 100800;
Si=ones(sizze,1);
ii=1:1:sizze;
ii=ii';


for i=1:1:sizze
pr= randi([4,6],1,1);
pr=pr./10;

 pd2 = makedist('Binomial','N',1,'p',pr);

 x1 = random(pd2,300,1);
 mx1= sum(x1);
 Si(i)= mx1;
end

avg= mean(Si);
vx = var(Si);





    

