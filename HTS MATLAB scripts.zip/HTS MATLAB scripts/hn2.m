function y1= hn2(t)

T =(t-32) .* (5./9); %convert temp to C

hfn2= 0;

%y1=  29e-3 + (.2199e-5).* T + (.5723e-8) .* (T.^2) + (-2.871e-12) .* (T.^3);

y1c =[ -2.871e-12 .5723e-8 .2199e-5 29e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfn2 + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%