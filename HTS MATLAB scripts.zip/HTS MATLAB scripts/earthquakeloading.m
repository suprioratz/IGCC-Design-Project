w12=2.464e4 ./1e3;
w23=4.6232e4 ./1e3;
w34=7.6861e3 ./1e3;
w45=3.4581e4 ./1e3;
w56=7.6861e3 ./1e3;
w67=4.4257e4 ./1e3;
w78=7.6861e3 ./1e3;
w89=6.7461e4 ./1e3;
w910=7.6861e3 ./1e3;
w1011=1.3198e5 ./1e3;
w1112=2.0169e4 ./1e3;

wi =[w12;w23;w34;w45;w56;w67;w78;w89;w910;w1011;w1112];

totalwt= sum(wi);

%all weights in lb converted to kips

hi12 =47.125;
hi23 =42.065;
hi34 =39.1675;
hi45 =36.86;
hi56 =34.553;
hi67 =31.755;
hi78 =28.6575;
hi89 =24.85;
hi910 =21.0125;
hi1011 =13.775;
hi1112 =3.625;

hi=[hi12;hi23;hi34;hi45;hi56;hi67;hi78;hi89;hi910;hi1011;hi1112];

wihi = wi .* hi;

swihi = sum(wihi);

z= 1; %zone factor
k= 2; % vessel factor, 2 for cylindrical
c = 0.1; %related to the inherent frequency
w = totalwt;

V= z .* k .* c .*w;
Ft = 0.15 .* V;

Fi = ((V-Ft) ./ swihi) .* wihi;



