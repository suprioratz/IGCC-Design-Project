function y1= hco2(t)

T= (t-32) .* (5 ./9); % convert temp to C

hfco2= -393.5; %kJ/mol at 25

%cp=  36.11e-3 + (4.233e-5).* T + (-2.887e-8) .* (T.^2) + (7.464e-12) .* (T.^3);

y1c =[ 7.464e-12 -2.887e-8 4.233e-5 36.11e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfco2 + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%