function y1= hzno(t) %input t in farenheit

T= (t-32) .* (5 ./9); % convert temp to C

hfzno= -350.5; %kJ/mol at 25 C

%y1=  40.3e-3 + 0.* T + 0.* (T.^2) + 0.* (T.^3);

y1c =[ 0 0 0 40.3e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfzno + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%