function y1= hh2(t) %input t in farenheit

T= (t-32) .* (5 ./9); % convert temp to C

hfh2= 0; %kJ/mol at 25 C

%y1=  28.84e-3 + (.00765e-5).* T + (.3288e-8) .* (T.^2) + (-.8698e-12) .* (T.^3);

y1c =[ -.8698e-12 .3288e-8 .00765e-5 28.84e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfh2 + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%