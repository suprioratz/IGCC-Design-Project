function y1= hh2s(t) %input t in farenheit

T= (t-32) .* (5 ./9); % convert temp to C

hfh2s= -19.96; %kJ/mol at 25 C

%y1=  33.51e-3 + (1.547e-5).* T + (.3012e-8) .* (T.^2) + (-3.292e-12) .* (T.^3);

y1c =[ -3.292e-12 .3012e-8 1.547e-5 33.51e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfh2s + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%