function y1=pdrop(G)

dp = .25; %in inch
miu = .025; % in cp, avg viscosity of inlet and outlet

nre = ( dp .* G) ./ miu;

s= .445; %.445 for catalyst
fk = 1.75 + (150 .* ( (1-s) ./ nre) );
pf = .483; %fluid density in lb/ cu ft

y1 = ((fk .* (G.^2) .* (1-s)) ./ ((dp./12) .* pf .* 32.17 .* (3600.^2) .* (s.^3)));
%psf/ft

y1 = y1 ./ 144; %psi/ft

end

