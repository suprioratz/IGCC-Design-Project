N=15; % no of bolts
sa = 13700; %allowable stress
ab = (3.1416 .* 11.9 .* 12 .* 1439) ./ (N .* sa); %bolt area sq in

boltdia= ((ab .* 4)./ 3.14) .^ 0.5;

