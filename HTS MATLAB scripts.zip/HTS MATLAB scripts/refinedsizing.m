% OPERATING WEIGHT CALCULATION, weight in lb
rhosh = 490; %lb /cu ft
rhof = 0.6261; %lb/ct ft @ 745 F of syngas
rhocat = 70; % lb cu ft @ bulk density
rhosp = 96.76; %lb cu ft @ bulk density
rhoCS = 0.284; %lb / cu in of ASTM A36 CS
vcat = .445; %voidage in cat
vsp = .45; %voidage in sp

%to section 2

tophead = 13617;
shell2= (3.1416 .* 11 .* (2.25 ./12) .* 3) .* rhosh; %dia 11 ft, thickness 2.25 in, 3 ft space
topbaffle= 200; %est
ringbaffle = 200 .* 2; %est
manhole2= 0;
thermwell2= 40 .*1; %est
clip2 = 500; %est, for ladder and platforms
ladder2 = 165; %est, 20lb/ft, 3+2.75 ft
fluid2 = (((3.1416 .* (11./2) .* 2.75) ./2)+ (.25 .* 3.1416 .* (11 .^2) .* 3)) .* rhof; % ellipse vol pi * a *b; a = D/2; b =2.75=(D./4)

sum2 = tophead+shell2+topbaffle+ringbaffle+manhole2+thermwell2+clip2+ladder2+fluid2;


%to section 3 (2-3 : cat)

cat3 = (.25 .* 3.1416 .* (11 .^ 2) .* 3.37) .* rhocat; %height of 1st bed 3.37 ft
sp3 =  (.25 .* 3.1416 .* (11 .^ 2) .* 1) .* rhosp; % .5 & .5 ft high sp above and bottom
thermwell3 = 40 .*1; %est
fluidc3 = ((.25 .* 3.1416 .* (11 .^ 2) .* 3.37) .* vcat) .* rhof; %fluid in cat voidage
fluidp3 = ((.25 .* 3.1416 .* (11 .^ 2) .* 1) .* vsp) .* rhof; %fluid in inert voidage
clip3 = 500;% est
ladder3 =87.4; %est, 20 lb/ft, (3.37 +1) ft
shell3 = (3.1416 .* 11 .* (2.25 ./12) .* 4.37) .* rhosh; %hieght (3.37 +1) ft

sum3 = cat3+sp3+thermwell3+fluidc3+fluidp3+clip3+ladder3+shell3;

%to section 4  (3-4 : HE)
HE4 = (3.1416 .* .787 .* (8.2e-3 .* 12) .* (6.72 .* 12)) .* rhoCS .* 262 .* 1.5; %no of tubes 262 in each bundle, thinkcess 8.2e-3,length 6.72 ft, ID .787 inch
thermwell4 = 40 .* 2;
shell4= (3.1416 .* 11 .* (2.25 ./12) .* 1.425) .* rhosh;
clip4 = 500; %est
ladder4 = 28.5; %same
plate4 = 300; %est
fluid4 = (.25 .* 3.1416 .* (11 .^ 2) .* 1.425) .* 0.75 .* rhof;

sum4 = HE4+thermwell4+shell4+clip4+ladder4+plate4+fluid4;

%to section 5 (4-5 : cat)
cat5 = (.25 .* 3.1416 .* (11 .^ 2) .* 2.19) .* rhocat; %height of 2nd bed 2.19 ft
sp5 =  (.25 .* 3.1416 .* (11 .^ 2) .* 1) .* rhosp; % .5 & .5 ft high sp above and bottom
thermwell5 = 40 .*1; %est
fluidc5 = ((.25 .* 3.1416 .* (11 .^ 2) .* 2.19) .* vcat) .* rhof; %fluid in cat voidage
fluidp5 = ((.25 .* 3.1416 .* (11 .^ 2) .* 1) .* vsp) .* rhof; %fluid in inert voidage
clip5 = 500;% est
ladder5 =63.8; %est, 20 lb/ft, 3.19 ft
shell5 = (3.1416 .* 11 .* (2.25 ./12) .* 3.19) .* rhosh; %hieght (2.19 +1) ft

sum5 = cat5+sp5+thermwell5+fluidc5+fluidp5+clip5+ladder5+shell5;

%to section 6 (5-6: HE)

HE6 = (3.1416 .* .787 .* (8.2e-3 .* 12) .* (6.72 .* 12)) .* rhoCS .* 262 .* 1.5; %no of tubes 262 in each bundle, thinkcess 8.2e-3,length 6.72 ft, ID .787 inch
thermwell6 = 40 .* 2;
shell6= (3.1416 .* 11 .* (2.25 ./12) .* 1.425) .* rhosh;
clip6 = 500; %est
ladder6 = 28.5; %same
plate6 = 300; %est
fluid6 = (.25 .* 3.1416 .* (11 .^ 2) .* 1.425) .* 0.75 .* rhof;

sum6 = HE6+thermwell6+shell6+clip6+ladder6+plate6+fluid6;

%to section 7 (6-7: cat)

cat7 = (.25 .* 3.1416 .* (11 .^ 2) .* 3.17) .* rhocat; %height of 2nd bed 2.19 ft
sp7 =  (.25 .* 3.1416 .* (11 .^ 2) .* 1) .* rhosp; % .5 & .5 ft high sp above and bottom
thermwell7 = 40 .*1; %est
fluidc7 = ((.25 .* 3.1416 .* (11 .^ 2) .* 3.17) .* vcat) .* rhof; %fluid in cat voidage
fluidp7 = ((.25 .* 3.1416 .* (11 .^ 2) .* 1) .* vsp) .* rhof; %fluid in inert voidage
clip7 = 500;% est
ladder7 =83.4; %est, 20 lb/ft, 4.17 ft
shell7 = (3.1416 .* 11 .* (2.25 ./12) .* 4.17) .* rhosh; %hieght (2.19 +1) ft

sum7 = cat7+sp7+thermwell7+fluidc7+fluidp7+clip7+ladder7+shell7;

%to section 8 (7-8: HE)

HE8 = (3.1416 .* .787 .* (8.2e-3 .* 12) .* (6.72 .* 12)) .* rhoCS .* 262 .* 1.5; %no of tubes 262 in each bundle, thinkcess 8.2e-3,length 6.72 ft, ID .787 inch
thermwell8 = 40 .* 2;
shell8= (3.1416 .* 11 .* (2.25 ./12) .* 1.425) .* rhosh;
clip8 = 500; %est
ladder8 = 28.5; %same
plate8 = 300; %est
fluid8 = (.25 .* 3.1416 .* (11 .^ 2) .* 1.425) .* 0.75 .* rhof;

sum8 = HE8+thermwell8+shell8+clip8+ladder8+plate8+fluid8;

%to section 9 (8-9: cat)

cat9 = (.25 .* 3.1416 .* (11 .^ 2) .* 5.52) .* rhocat; %height of 2nd bed 2.19 ft
sp9 =  (.25 .* 3.1416 .* (11 .^ 2) .* 1) .* rhosp; % .5 & .5 ft high sp above and bottom
thermwell9 = 40 .*1; %est
fluidc9 = ((.25 .* 3.1416 .* (11 .^ 2) .* 5.52) .* vcat) .* rhof; %fluid in cat voidage
fluidp9 = ((.25 .* 3.1416 .* (11 .^ 2) .* 1) .* vsp) .* rhof; %fluid in inert voidage
clip9 = 500;% est
ladder9 =130.4; %est, 20 lb/ft, 6.52 ft
shell9 = (3.1416 .* 11 .* (2.25 ./12) .* 6.52) .* rhosh; %hieght (2.19 +1) ft

sum9 = cat9+sp9+thermwell9+fluidc9+fluidp9+clip9+ladder9+shell9;

%to section 10 (9-10: HE)

HE10 = (3.1416 .* .787 .* (8.2e-3 .* 12) .* (6.72 .* 12)) .* rhoCS .* 262 .* 1.5; %no of tubes 262 in each bundle, thinkcess 8.2e-3,length 6.72 ft, ID .787 inch
thermwell10 = 40 .* 2;
shell10= (3.1416 .* 11 .* (2.25 ./12) .* 1.425) .* rhosh;
clip10 = 500; %est
ladder10 = 28.5; %same
plate10 = 300; %est
fluid10 = (.25 .* 3.1416 .* (11 .^ 2) .* 1.425) .* 0.75 .* rhof;

sum10 = HE10+thermwell10+shell10+clip10+ladder10+plate10+fluid10;

%to section 11 (10-11: cat)

cat11 = (.25 .* 3.1416 .* (11 .^ 2) .* 12.05) .* rhocat; %height of 2nd bed 2.19 ft
sp11 =  (.25 .* 3.1416 .* (11 .^ 2) .* 1) .* rhosp; % .5 & .5 ft high sp above and bottom
thermwell11 = 40 .*2; %est
fluidc11 = ((.25 .* 3.1416 .* (11 .^ 2) .* 12.05) .* vcat) .* rhof; %fluid in cat voidage
fluidp11 = ((.25 .* 3.1416 .* (11 .^ 2) .* 1) .* vsp) .* rhof; %fluid in inert voidage
clip11 = 500;% est
ladder11 =261; %est, 20 lb/ft, 13.05 ft
shell11 = (3.1416 .* 11 .* (2.25 ./12) .* 13.05) .* rhosh; %hieght (2.19 +1) ft

sum11 = cat11+sp11+thermwell11+fluidc11+fluidp11+clip11+ladder11+shell11;




sumint = sum2+sum3+sum4+sum5+sum6+sum7+sum8+sum9+sum10+sum11;

%to section 12 - (11-12: skirt)

bothead = tophead;
tsk = 0.15; %in inch, calc from wind load condition, iterate after quake condition
wskt =  3.1416 .* (11 .*12) .* tsk .* (7.25 .* 12) .* rhoCS;
fluid12 = ((3.1416 .* (11./2) .* 2.75) ./2) .* rhof;
rings_stiff = 5000;

skirt = bothead+wskt+fluid12+rings_stiff;

totalwt= sumint + skirt;



































 





