function y1= hh2o(t)

T= (t-32) .* (5 ./9); % convert temp to C

hfh2o = -241.83; %kJ/mol

%y1=  33.46e-3 + (.688e-5).* T + (.7604e-8) .* (T.^2) + (-3.593e-12) .* (T.^3);

y1c =[ -3.593e-12 .7604e-8 .688e-5 33.46e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfh2o + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input T is in F%