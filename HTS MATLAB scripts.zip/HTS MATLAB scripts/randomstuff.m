%order co, h2o, co2, h2, ch4, n2%

mco = 4418.85; %lbmol/hr
mh2o= (mco .* 5); %5:1 steam to CO change this if needed
mco2= 1055.76; %lb mol /hr
mh2= 2892.23;
mch4= .8096;
mn2= 213.972;

g= [ mco; mh2o; mco2; mh2; mch4; mn2];
gtot = sum (g);

gy = g ./ gtot;

Tin= 630; %feed temp in F 630 nominal feed temp
dT= 1;
i=0;
j=1;
bedno=1;
W=[];
Tout=[];
dco=[];
intconv=[];
intfrac=[];
cpcatl = 26.148; %kJ/lb mol

%input data complete
while 1 
  if i==0  %for initial chunk
Ti= Tin;
Fico = mco;
Fih2o = mh2o;
Fico2 = mco2;
Fih2 = mh2;
Fich4 = mch4;
Fin2 = mn2;

yco= gy(1,1);
yh2o= gy(2,1);
yco2= gy(3,1);
yh2=  gy(4,1);
ych4= gy(5,1);
yn2=  gy(6,1);
  else      %for every other chunk

              if Ti2==790   %790 is the design max temp for bed
                 intfrac(:,bedno) = [yi2co;yi2h2o;yi2co2;yi2h2;yi2ch4;yi2n2];
                 Ti=Ti2-90; %cool down 90 F
                 intbedconv = ((mco-Fi2co) ./ mco) .* 100; %for conv uptil bedno
                 intconv(1,bedno)= intbedconv;
                 
                 bedno= bedno+1;
                 %disp(bedno)
                 j=1;
                 
               Fico = Fi2co;
               Fih2o = Fi2h2o;
               Fico2 = Fi2co2;
               Fih2 = Fi2h2;
               Fich4 = Fi2ch4;
               Fin2 = Fi2n2;

               yco= yi2co;
               yh2o= yi2h2o;
               yco2= yi2co2;
               yh2=  yi2h2;
               ych4= yi2ch4;
               yn2=  yi2n2;
              else
Ti= Ti2;
Fico = Fi2co;
Fih2o = Fi2h2o;
Fico2 = Fi2co2;
Fih2 = Fi2h2;
Fich4 = Fi2ch4;
Fin2 = Fi2n2;

yco= yi2co;
yh2o= yi2h2o;
yco2= yi2co2;
yh2=  yi2h2;
ych4= yi2ch4;
yn2=  yi2n2;
              end
  end
%disp(Ti)

%following portion is the iterative process 

Ti2= Ti+ dT;

Tout(j,bedno) = Ti2;

Tavg = (Ti + Ti2) ./ 2;

hr = hwg(Tavg); %heat of reaction

mi = [Fico; Fih2o; Fico2; Fih2; Fich4; Fin2];

Hi = [ hco(Ti); hh2o(Ti); hco2(Ti); hh2(Ti); hch4(Ti); hn2(Ti)];

Hi2 = [ hco(Ti2); hh2o(Ti2); hco2(Ti2); hh2(Ti2); hch4(Ti2); hn2(Ti2)];

delH = [Hi2 - Hi];

delF = mi .* delH;

sdelF= sum(delF);

asd = (hco(Ti2) + hh2o(Ti2) - hco2(Ti2) - hh2(Ti2) + hr);

del =sdelF ./ asd;

Fi2co = Fico-del;
Fi2h2o = Fih2o-del;
Fi2co2 = Fico2+del;
Fi2h2 = Fih2+del;
Fi2ch4 = Fich4;
Fi2n2 = Fin2;

FT = (Fi2co + Fi2h2o + Fi2co2 + Fi2h2 + Fi2ch4 + Fi2n2);

yi2co= Fi2co ./ FT;
yi2h2o= Fi2h2o ./ FT;
yi2co2= Fi2co2 ./ FT;
yi2h2=  Fi2h2 ./ FT;
yi2ch4= Fi2ch4 ./ FT;
yi2n2=  Fi2n2 ./ FT;

ri= rwg(Ti,yco,yh2o,yco2,yh2);
ri2= rwg(Ti2,yi2co,yi2h2o,yi2co2,yi2h2);

ravg= (ri + ri2) ./2;

%%%%from here modification starts
intdelW = (del ./ ravg);

asd2 = (hco(Ti2) + hh2o(Ti2) - hco2(Ti2) - hh2(Ti2) + hr - (intdelW .* cpcatl) );
del2 =sdelF ./ asd2;

Fi2co = Fico-del2;
Fi2h2o = Fih2o-del2;
Fi2co2 = Fico2+del2;
Fi2h2 = Fih2+del2;
Fi2ch4 = Fich4;
Fi2n2 = Fin2;

FT = (Fi2co + Fi2h2o + Fi2co2 + Fi2h2 + Fi2ch4 + Fi2n2);

yi2co= Fi2co ./ FT;
yi2h2o= Fi2h2o ./ FT;
yi2co2= Fi2co2 ./ FT;
yi2h2=  Fi2h2 ./ FT;
yi2ch4= Fi2ch4 ./ FT;
yi2n2=  Fi2n2 ./ FT;

ri= rwg(Ti,yco,yh2o,yco2,yh2);
ri2= rwg(Ti2,yi2co,yi2h2o,yi2co2,yi2h2);

ravg= (ri + ri2) ./2;

delW = (del2 ./ ravg);

%%%here it ends
W(j,bedno) =delW;

dryco = ( yi2co ./ (1-yi2h2o));

dco(j,bedno) = dryco;

i=i+1;
j=j+1;
       
           if dryco < .03 %set dry gas co frac to desired final frac, 3% nominal conc
           
           break
           end

end %it works :D !!!

perbed= sum(W);
perbedVol = (perbed ./ 70); %ans in cu ft

totalcat= sum(perbed);
totalcatVol= (totalcat ./ 70) ; %ans in cu ft

conv = ((mco - Fi2co) ./ mco) .* 100;