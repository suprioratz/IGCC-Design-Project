function y1= hwg(T)

%input Temp is in F

tc= (T-32) .* (5 ./ 9); % to C

t = tc + 273; %to K

y2 = -11373 + (3.11 .* t) - (0.3e-3 .* t.^2) + (1.89e5 .* t.^-1);

y1 = -1 .* y2; %output unit is cal/ mol

y1 = (y1 .* 4.184) ./ 1000; %output unit is kJ/mol

y1 = (y1 .* 453);  %output unit is kJ/ lb mol

end