kst= 40; %W/m-k, thermal conductivity of the steel type used in vessel shell 
kin = .03; %W/m;k, thermal conductivity of glass wool
hair = 30; %W/m2-k
tst= 2.25; %steel thickness, in inch
rsti= (66 ./12) .* 3048; %in meter, inner radius of reactor
rsto= ((66+tst)./12) .*3048; %in meter, outer radius of reactor


L= .3048; % in m, = 1 ft
Tst=421; %deg C
Tair=35; %deg C
Ast2 = 2 .* 3.1416 .* ((5.5+ (tst ./ 12)) .* .3048) .* L; % in m2

q = (Tst-Tair) ./    ( ((log(rsto./rsti)) ./ (2 .* 3.1416.* kst .* L)) + ( 1./ (hair .* Ast2)) ) ; %heat loss uninsulated, W


tin = 3; %%nominal value of insulation thickness
rin = ((66+tst+tin)./12) .*3048;
An = 2 .* 3.1416 .* ((5.5+ ( (tst+tin) ./ 12)) .* .3048) .* L;
qn=(Tst-Tair)./ ( ((log(rsto./rsti))./(2 .* 3.1416.* kst .* L))+((log(rin./rsto))./ (2 .* 3.1416.* kin .* L))+( 1./ (hair .* An)) );

prct = (qn ./ q) .* 100;


mid =  qn .* ((log(rsto./rsti)) ./ (2 .* 3.1416.* kst .* L));
Tst1 = Tst -mid; %insulator inner-surface/reactor body outser surface temperature


mid2 = qn .* ((log(rin./rsto)) ./ (2 .* 3.1416.* kin .* L));
Tin = Tst1 -mid2; %insulator outser surface temperature