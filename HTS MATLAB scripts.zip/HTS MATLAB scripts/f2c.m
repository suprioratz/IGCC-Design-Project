function y1= f2c(F)

y1 = (5 ./9) .* (F-32);

end 
