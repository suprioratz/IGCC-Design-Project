
function y1= tgrad(G,T,yco,yh2o,yco2,yh2,ych4,yn2) %temp in F
%the fractions are molar fraction at the input to the reactor
 reacrate = rwg(T,yco,yh2o,yco2,yh2);  % ok

dp =  .25; %in inch
miu = .0242; %in cp, average viscosity at the inlet
%mass flux G is in lb/hr/ft2
pp = 126; % particle density, in lb/ cu ft
Nre =  ((1.225 .* dp .* G) ./ (12 .* miu .* 2.42));
am = (6 .* 12) ./ (dp .* pp); %sq ft /lb cat

mean = meanmwt(yco,yh2o,yco2,yh2,ych4,yn2);
Rm = (reacrate .* mean) ./ (am .* G);
delH = hwg(T); %temp in F
cpm = 14; %manually calculated in kJ/lbmol/C using const individual cp 

qm = Rm .* (delH ./  cpm);

y1 =[qm Rm Nre];
end

