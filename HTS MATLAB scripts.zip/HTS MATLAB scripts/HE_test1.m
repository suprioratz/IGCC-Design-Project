Tgi=421.1; %in C
dTF = 90; %in F
dT = dTF ./ 1.8; %in C
Tgo = Tgi - dT;

Twi = 35; %in C
Two= 325.6; %in C, at 12.3 MPa Sat'd condition

Tavgg = (Tgi+Tgo)./2;
Tavgw = (Twi+Two) ./2;

cof = 1; %close to 1, see cengel heat transfer for cross flow
LMTD = cof .* ( ((Tgi - Two) - (Tgo -Twi)) ./ log( (Tgi - Two)./(Tgo -Twi) ) );
Q = 7400; %in kW

%properties of syngas and water at avg temp

%water properties
rhow= 883 ; %kg/ cu m
spvw= 1./ rhow; %cu m/kg
niuw = 0.1688; % in cSt --- multiply by 1e-6 to get in sq m/s
kw = 0.6765; % W/m C
miuw = 0.149; % in cP ---multiply by 1e-3 to get in Pa.s
cpw = 4.672; % in kJ/kg C

Prw = (((miuw .* 1e-3) .* ( cpw .* 1e3)) ./ kw);

%syngas properties
rhog= 10.03 ; %kg/ cu m
spvg= 1./ rhog; %cu m/kg
niug = 2.22; % in cSt --- multiply by 1e-6 to get in sq m/s
kg = 8.128e-2; % W/m C
miug = 2.226e-2; % in cP ---multiply by 1e-3 to get in Pa.s
cpg = 2.02; % in kJ/kg C

Prg = (((miug .* 1e-3) .* ( cpg .* 1e3)) ./ kg);

%structural features

%there are two tubes, internal tube- material Carbon Steel

din = 0.020; %in m
dtin = 2.5e-3; % in m

%external tube is with helical finning- material Aluminium/Aluminium Alloy
df = 0.028; %in m, dia of fin carrying tube
lr = 0.0135; % fin height in m
sr = 0.003; % fin spacing in m
dr = 8e-4; % avg fin thickness
Rcont = 1.89e-4 ; %thermal contact resistance on steel-aluminium surface in m2 K/W


%calc begins

%SECTION 1: Specific Geometrif Characteristics of Finned Tubes

%Ar1 = surface of fins per 1m of length
Lrs = 1; %length of finned segment of tube in m
z =1; %no of tubes in bundle

D = df+ 2.* lr; %in m, finning diameter

Ar1= (3.1416./ 2).*((D .^2) - (df.^2) + (2 .*D.*dr)).*(Lrs./sr).*z;

%At1 = surface are of carrying tube not occupied by fins per 1 of the
%length of the finnned tube
Lt= 0; % total length of heated unfinned segments ie the bends
At1 = 3.1416 .* df .* ( Lrs.* (1 - (dr./sr)) .*z + Lt);

%A1 = outside surface are per 1m of tube length

A1 = Ar1+At1;

ArbyA = (Ar1 ./ A1);
AtbyA = (At1 ./A1);

%Arct1 = total surface are of finning carrying tube per 1m of tube length
Lr =1; %tube length in m 
Arct1 = 3.1416 .* df .* Lr;

%Ain1 = are of inside surface per 1m of tube length
Ain1 = 3.1416 .* din .* Lr;

AbyAin = (A1 ./ Ain1);
psir = (A1 ./Arct1);

%SECTION 2: DIMENSION OF GAS CONDUIT AND SPACING CHARACTERISTICS OF WAHE

%maximally dense equilateral arrangement of the bundle, with which the
%longitudinal and transverse spacings are related

%S2 = (sqrt(3) ./ 2) .* S1;
% S1 = transeverse tube spacing, accounting maximum transverse dimension of
% the finned tube ie the outer diameter of finning D
%a = width of gas conduit; b = height/length of gas conduit

a= 2.6; %in m
b = 2.05; %in m

%z1 = no of tubes in transverse rows of the bundle

z1=0;
while 1
  z1=z1+1;
  S1 = a ./ (z1+0.5);
  
       if S1<D
       z1= z1-4; % increase the value from '4' for higher clearance
       S1 = a ./ (z1+0.5);
       break
       end
end

S2 = (sqrt(3) ./ 2) .* S1;
S2d =S1; %diagonal tube spacing

%sigmas are relative spacing characteristics

sig1 = S1 ./ df;
sig2 = S2 ./ df;
sig2d = S2d ./ df;

sig1bysig2 = sig1 ./ sig2;

%SECTION 3: Free Area for Passage of Air and Air Velocity Calc
%dcl = conventional diameter of the finned tube
dcl = df + (( 2.* lr .* dr) ./ sr);
%bundle diameter phicl(?)
phicl = ( S1 - dcl) ./ (S2d - dcl);

%since phicl <=2 we will use the follwing for minimum free area which is
%located at the transverse spacing plane

%F = minimum free area
%Lccrs = b, length of tubes whithin the confines of the gas conduit height
Lccrs = b;
F = (a.* b) - (z1 .* Lccrs .* dcl); % in sq m

Gg = 73.08; % gass mass flow rate, kg/s

ug = (Gg .* (1./ rhog)) ./ F; %gas velocity m/s

%SECTION 4 : Free area for passage of water and average water velocity

nx= 2;
ztcp = nx .* z1;
f = ztcp .* (3.1416./4) .* (din .^2);
Gf = 5.04; %water mass flowrate in kg/s
uf = (Gf .* ( 1./ rhow)) ./ f;

%SECTION 5: Overall HTC

phi = 1; %thermal efficiency, depends on mediums
RT = Rcont;

%SECTION 5a|| reduced heat transfer coefficient h1rdc

%h1rdc=( (Ar/A)*E*miur*psiE + (At/A) ) * hc

X = sig1bysig2 - (1.26./psir) -2;%shape parameter of bundle for staggerd arrangement
n = 0.7+ (0.08 .* tanh(X) ) + (0.005 .* psir);

Cq = (1.36- tanh(X)) .* ( (1.1./(psir+8)) -0.014);

Cz =1; %since z2>10

hc = 1.13.*Cz.*Cq.*(kg ./ df).*( ((ug.* df)./(niug .*1e-6)) .^ 0.715).*(Prg.^0.33);

Ed = 0.9; %assumed, this will be iterated

while 1

Tr = Tavgg - ((Tavgg-Tavgw).*Ed);

kr = Aluk(Tr); %code for manual input---input(['enter thermal conductivity of aluminium at Temp ' num2str(Tr) 'C\n']);

beta = sqrt( (2.* hc) ./ (dr .* kr)); % in per m

%lrd = conventional fin height

lrd= lr.*(1+ ((0.191+ (0.054 .* (D./df))) .* (log(D./df))));

E = (tanh(beta .* lrd) ./ (beta.*lrd));

                      if ((abs(E-Ed))./Ed) < .01
                      break
                      else
                      Ed=E;
                      end
end

psiE = 1- (0.016 .*((D./df)-1) .* (1+tanh((2.*beta.*lr) -1)));

miur =1; %factor considering fin thickness variation

h1rdc=((ArbyA.*E.*miur*psiE) + AtbyA).*hc;


%%SECTION 5b|| Coefficient of Heat Transfer From wall to Internal Medium h2


Ref = (uf .* din) ./ (niuw .* 1e-6);

lamb = 1+ (900 ./ Ref);
zeta = ((1.82 .* (1./2.302) .* log(Ref))-1.64) .^ (-2);

Ad= 100; %m2, assumed, will iterate
h2d= 3500; %W/m2 K, assumed will iterate
 
while 1

Aind = (Ad ./ AbyAin);
Tind = Tavgw + (Q.* 1e3 ./ (Aind .* h2d));

miuin = miuh2o(Tind);

Cterm = (miuw ./ miuin) .^0.11;

h2 = (kw ./ din) .* ((0.125.*zeta.*Ref.*Prw.*Cterm)./ (lamb + (4.5.* (sqrt(zeta)).* (((Prw).^0.666)-1))));

U = 1 ./ ((AbyAin.*(1./h2)) + (AbyAin.*RT)+ (1./h1rdc)); %in W/m K

A = (Q .* 1e3) ./ (U .* LMTD);

Ain = A ./ (AbyAin);

Tin = Tavgw + ((Q .* 1e3) ./ (Ain .* h2));

     if ((abs (Tin-Tind))./Tind)<0.01

     break

     else 
     Ad=A;
     h2d=h2;
     end
end

Lfintotal = (A ./ A1);
totalnotubes = (Lfintotal ./ Lccrs);
notransverserow = (totalnotubes ./z1); %z1 each row tube number
z2= notransverserow+1;
%c= depth of gas conduit
c= (z2-1) .* S2;
actnotube = z1 .* z2;
Lactfintube = Lccrs .* actnotube;

depth= c ./ .3048;










                 























