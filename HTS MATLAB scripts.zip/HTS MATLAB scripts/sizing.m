%mass flow is in lb/hr
corrA = .125; %in
ro = 490; % 2.25Cr-1Mo SS material density in lb/ cu ft
noHE = 4;
hHE = 1; % in ft, used 1.425 actually
HE = hHE .* noHE;


space= 3; %in ft head space

spp = 2.5+4; %in ft, 4 = cat support on top and botton for 4 beds, each has 0.5 ft and  0.5 ft
             %2.5 is probably for

addedH = spp+space+HE; %in ft

mass= 580000; %lb/hr

D= [14 13 12 11 10 9]; %ft
L = [19 21 24 28 33 40]; %ft

A = .25 .* 3.1416 .* (D.^2); % sq ft

G = mass ./ A; %lb/hr/sq ft

[m,n] = size(G);

bedvol = [320.84 208.85 302.03 524.44 1146];

[p,q]=size(bedvol); %input each bed vol in cu ft

acptG = [];
acptL=[];
acptD =[];

ii=1;
jj=1;
kk=1;
bedh=[];

for j=1:1:n

   if G(1,j)> 1400
    acptG(1,kk) = G(1,j);
    acptD(1,ii) = D(1,j);
    ii=ii+1;
    kk=kk+1;
   end
end


acptA = .25 .* 3.1416 .* (acptD .^2);

[pp,qq] = size (acptA);

for yu=1:1:qq  %to find the bed length for catalyst

        for ui=1:1:q

 bedh(ui,yu) = (bedvol(1,ui)) ./ (acptA(1,yu));

        end
end

catl = sum(bedh);

acptL = catl+addedH;

designp = 415; % in psig DESIGN PRESSURE;nominal vlaue 430 - now use 415!!
R = (acptD .* 12) ./2; %radius in inch

S = 13100 ;%allowable stress at design temp 900 F in psi
E= 1; %joint efficiancy

t = ((designp .* R) ./ ( (S.*E) - (0.6 .* designp))); % thickness in inch

tact = t+corrA; %added corrosion allowance in inch

shell = 3.1416 .* acptD .* (tact ./ 12) .* acptL .* ro; %shell mass in lb

head = ro .* (3.1416 ./4) .* (((1.23 .* acptD) + (tact ./12)) .^ 2) .* (tact ./12) .*2; %2:1 ellipsoidal head mass for top and bottom heads

totalwt = shell+ head;
price = .73; % $/lb of material

cost = totalwt .* price;



figure
subplot(3,1,1)
plot(acptL,cost,'-.o')
xlabel('length ft')
ylabel('Cost $')
subplot(3,1,2)
plot(acptD,cost,':o')
xlabel('diameter ft')
ylabel('Cost $')
subplot(3,1,3)
plot(tact,cost,'--o')
xlabel('thickness inch')
ylabel('Cost $')















