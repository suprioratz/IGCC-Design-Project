%flowrate in lb-mol/hr

mco= 4418.85; %%specify the flowrate into the reactor there
mh2o=1975.14;
mco2= 1055.76;
mh2= 2892.23;
mn2= 213.972;
mch4= 0.809602;
mh2s=19.148;
mzno= mh2s;
mzns=mzno;

min= [mco;mh2o;mco2;mh2;mn2;mch4;mh2s;mzno]; 

tin=632; %temp in F %% CHANGE THIS INPUT TEMP TO DESULFURISER AND CHECK OUTPUT
         %nominal value is 632

hin = [hco(tin);hh2o(tin);hco2(tin);hh2(tin);hn2(tin);hch4(tin);hh2s(tin);hzno(tin)];

ein= min .* hin;

hdes = 75.7; %kJ/mol, heat of reaction, exothermic reaction.

hdes = (hdes .* 453); %kJ/lb-mol

ext= mh2s;

hrIN = ein + (ext .* hdes);

hrIN = sum(hrIN);

hfatout = [ (-110.52 .* 453);(-241.83 .* 453);(-393.5 .* 453);(0 .* 453);(0 .* 453);(-74.85 .* 453);(-204.6 .* 453)];
%kJ/lbmol
%%hf of ZnS = -204.6 kJ/mol

matout= [mco; (mh2o+mh2s); mco2; mh2; mn2; mch4; mzns];

cpatout =[ 28.95e-3; 33.46e-3; 36.11e-3; 28.84e-3; 29e-3; 34.31e-3; 45.71e-3]; %at kJ/mol/K
cpatout = 453 .* cpatout; % at kJ/lb-mol/K(C)

%%cp pf ZnS = 469 J/kg/k, MW = 97.47 g/mol; cp =45.71e-3 kJ/mol/K 

asd1 = (matout .* hfatout);
asd2 = (matout .* cpatout);

res1 = ((hrIN - sum(matout .* hfatout)) ./ (sum(matout .* cpatout)));

res2 = res1 + 25;

res3 = c2f(res2); %%res3 will give the output temp in F.
 %%% required output temp is around 630 F, use a cooler if necessary.
 
















