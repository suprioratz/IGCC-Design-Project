function y1= hco(t)

T= (t-32) .* (5 ./9); % convert temp to C

hfco = -110.52; %kJ/mol at 25 C

%y1=  28.95e-3 + (.4110e-5).* T + (.3548e-8) .* (T.^2) + (-2.22e-12) .* (T.^3);

y1c =[ -2.22e-12 .3548e-8 .411e-5 28.95e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfco + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F%
