function y1= meanmwt(yco,yh2o,yco2,yh2,ych4,yn2)

y1 = ((yco .* 28) + (yh2o .* 18) + (yco2 .* 44) + (yh2 .* 2) + (ych4 .* 16)+ (yn2 .* 28));

end 