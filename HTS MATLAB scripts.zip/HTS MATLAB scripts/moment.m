
w1= 317.4; %in lb /ft, from top
w2= 238.05;
p1=20; %in ft, 1st top portion
p2=30; % in ft, 2nd portion from top

%shear force diagram
%section 1- section ab

xab = [0:0.1:p1];
Vab = - w1 .* xab;

%section 2-section bc

xbc = [p1:0.1:(p1+p2)];
Vbc = -((w1-w2).*p1) - (w2 .* xbc);

figure
subplot(3,1,2)
pos = get(gca, 'Position');
    pos(1) = 0.055;
    pos(3) = 0.9;
    set(gca, 'Position', pos)
plot(xab,Vab);
xlabel('Distance from top (ft)')
ylabel('Shear force (lb)')
hold on
plot(xbc,Vbc);

hold off

%%bendig moment diagram
%section 1-section ab
Mab = -0.5 .* w1 .* (xab .^2);
Mbc = -( p1.* (w1-w2) .* (xbc - (p1./2))) - ( w2 .* 0.5 .* ( xbc .^2));

subplot(3,1,3)
pos = get(gca, 'Position');
    pos(1) = 0.055;
    pos(3) = 0.9;
    set(gca, 'Position', pos)
plot(xab,Mab);
xlabel('Distance from top (ft)')
ylabel ('Moment (lb-ft)')
hold on
plot(xbc,Mbc);
hold off

%%loading diagram


[r1,q1] = size (xab);
y1 = ones(r1,q1);
y1(:,:) = w1;

[r2,q2] = size (xbc);
y2 = ones(r2,q2);
y2(:,:) = w2;

subplot(3,1,1)
pos = get(gca, 'Position');
    pos(1) = 0.055;
    pos(3) = 0.9;
    set(gca, 'Position', pos)
plot(xab,y1);
xlabel('Distance from top (ft)')
ylabel ('Wind load (lb)')
hold on
plot(xbc,y2);
hold off

