function y1 = Cuk(T) %input temp is in C
K= 273+T; 


CuTemp = [10 20 40 60 80 100 200 300 400 500 600 800 1000 1200 1400];
%above temp in K

CuthermCond = [19e3 10700 2100 850 570 483 413 398 392 388 383 371 357 342];
%above K in W/m K

z=15;
i=1;

while 1

  if (K>=CuTemp(1,i)) && (K<=CuTemp(1,i+1))

  p1= i;
  p2= i+1;
  break
 
  else
  i=i+1;
  end
end

k1 = CuthermCond(1,p1);
k2 = CuthermCond(1,p2);

t1= CuTemp(1,p1);
t2= CuTemp(1,p2);

k = (((k2-k1) ./ (t2-t1)) .* (K-t1)) + k1;

y1=k;
