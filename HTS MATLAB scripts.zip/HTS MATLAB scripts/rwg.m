function y1 = rwg(T,yco,yh2o,yco2,yh2)

%input T is in F, the temp at the inlet section (or any portion for that
%matter, the mole fractions are in wet basis (actual fractions), the
%reaction rate represents midlife activity, units are lb moles CO
%converted/(lb catalyst) (hr)

temp = T + 460; %converting to rankine

if (temp<=1060) && (temp>=760)

Keq= exp(-4.72+ (8640 ./ temp)); %equilibrium constant%

%fprintf ('Keq is %f\n', Keq);

elseif (temp<=1360) && (temp>=1060)

Keq= exp(-4.33+ (8240 ./ temp));
%fprintf ('Keq is %f\n', Keq);

elseif temp<760

Keq= exp(-4.72 + (8640 ./ temp));
fprintf ('Keq is %f\n', Keq);


elseif temp>1360 

Keq= exp(-4.33 + (8240 ./ temp));
%fprintf ('Keq is %f\n', Keq);


end

k= exp(15.95 - (8820 ./ temp)); %rate constant%

%fprintf ('k is %f\n', k);
 
AF = 4; %activity factor%

pb = 70 ; %catalyst bulk density (lb/ft3)%

y1 = 4 .* ( k ./ (379 .* pb)) .* ( (yco .* yh2o) - ( ( (yco2 .* yh2) ./ Keq)));

end




