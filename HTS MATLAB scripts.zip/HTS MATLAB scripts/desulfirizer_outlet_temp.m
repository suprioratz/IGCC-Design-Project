ih2o= 895.92;
in2 = 97.057;
ico = 2004.37;
ico2 =478.889;
ih2 = 1352.77;
ich4 =0.3672;
ih2s =8.6855;
izno =8.6855;
izns =0;

min =[ih2o; in2; ico; ico2; ih2; ich4; ih2s; izno; izns]; %kmol/hr

oh2o = ih2o+ih2s;
on2 = in2;
oco = ico;
oco2 =ico2;
oh2 =ih2;
och4 =ich4;
oh2s =0;
ozno =0;
ozns = izno;

mo = [oh2o; on2; oco; oco2; oh2; och4; oh2s; ozno; ozns]; %kmol/hr

tin =333.3; % in celcius
energy = [hh2o(tin); hn2(tin); hco(tin); hco2(tin); hh2(tin); hch4(tin); hh2s(tin); hzno(tin); hzns(tin)];
energy = energy .* 1e3; %enthalpy in kJ/kmol
energyin = energy .* min; %kJ/hr

absin = abs(energyin);


for tout= 250:0.005:400

    energyo1= [hh2o(tout); hn2(tout); hco(tout); hco2(tout); hh2(tout); hch4(tout); hh2s(tout); hzno(tout); hzns(tout)];
    energyo = energyo1 .* 1e3;
    energyout = energyo .* mo;

    absout = abs (energyout);
    error = absout -absin;
    ep = (error/absin) .* 100;
    
    if ep <1
       break
    end
end
    
    