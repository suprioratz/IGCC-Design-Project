function y1 = Aluk(T) %input temp is in C
K= 273+T; 


AluTemp = [10 20 40 60 80 100 200 300 400 500 600 800 1000 1200 1400];
%above temp in K

AluthermCond = [38e3 13500 2300 850 380 300 237 273 240 237 232 220 93 99 105];
%above K in W/m K

z=15;
i=1;

while 1

  if (K>=AluTemp(1,i)) && (K<=AluTemp(1,i+1))

  p1= i;
  p2= i+1;
  break
 
  else
  i=i+1;
  end
end

k1 = AluthermCond(1,p1);
k2 = AluthermCond(1,p2);

t1= AluTemp(1,p1);
t2= AluTemp(1,p2);

k = (((k2-k1) ./ (t2-t1)) .* (K-t1)) + k1;

y1=k;


