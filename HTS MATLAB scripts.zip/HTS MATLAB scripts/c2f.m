function y1= c2f(C)

y1 = (( 9./5) .* C) + 32;

end
