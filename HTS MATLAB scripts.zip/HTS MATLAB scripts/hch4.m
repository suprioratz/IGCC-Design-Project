function y1= hch4(t)

T= (t-32) .* (5 ./9); % convert temp to C

hfch4 = -74.85; %kJ/mol at 25 C

%cp=  34.31e-3 + (5.469e-5).* T + (.3661e-8) .* (T.^2) + (-11e-12) .* (T.^3); %cp is found in kJ/mol/C or kJ/mol/K where input T is in C%

y1c =[ -11e-12 .3661e-8 5.469e-5 34.31e-3 ];

q = polyint(y1c);
valy1 = diff (polyval (q, [25 T]));

y1= hfch4 + valy1;

y1= y1 .* (453); %h is found in kJ/lb mol

end

%input t is in F


