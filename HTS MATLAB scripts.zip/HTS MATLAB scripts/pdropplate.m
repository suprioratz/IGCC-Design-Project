%pressure on each plate

D= 11; %ft
Din = 11 .* 12; %in
g= 32.174;%ft/sq s
Ain= .25 .* 3.1416 .* Din.^2; %sq in
A= .25 .* 3.1416 .* D.^2; %sq ft
%bulk density of catalyst 70 lb / cu ft
%inert are 1/2'' ceramic balls , voidage .45, .6517 psi/ft
%cat are 1/4'' x 1/4'' cylindrical pellets, voidage .445, .6801 psi/ft
%inert bulk density  96.76 lb / cu ft

%Plate 1 - 3.3761 ft, .5 ft & .5 ft

pin1= .6571 .* (.5+.5);
pcat1= .6801 .* 3.3761;
plate1=0;
bed1 = 22459+ ((A.*1) .* 96.76); %lbm
bedf1 = bed1 .*g;
wtp1 = bedf1 ./ Ain;

p1 = pin1+pcat1+plate1+wtp1;
pd1 = pin1+pcat1+plate1;

%plate 2 - 2.1976 ft, .5 ft, .5 ft
pin2= .6571 .* (.5+.5);
pcat2= .6801 .* 2.1976;
plate2=0;
bed2 = 14620+ ((A .*1) .* 96.76); %lbm
bedf2 = bed2 .*g;
wtp2 = bedf2 ./ Ain;

p2= pin2+pcat2+plate2+wtp2;
pd2 = pin2+pcat2+plate2;

%plate 3 - 3.1781 ft, .5 ft, .5 ft
pin3 = .6571 .* (.5+.5);
pcat3 = .6801 .* 3.1781;
plate3 = 0;
bed3= 21143 +((A.*1) .* 96.76); %lbm
bedf3 = bed3 .* g;
wtp3 = bedf3 ./ Ain;

p3 = pin3+pcat3+plate3+wtp3;
pd3 = pin3+pcat3+plate3;

%plate 4 - 5.5185 ft, .5 ft, .5 ft
pin4 = .6571 .* (.5+.5);
pcat4 = .6801 .* 5.5185;
plate4=0;
bed4 = 36711+ ((A.*1) .* 96.76); %lbm
bedf4 = bed4 .* g;
wtp4 = bedf4 ./ Ain;

p4=pin4+pcat4+plate4+wtp4;
pd4 = pin4+pcat4+plate4;

%plate 5 - 12.0589 ft, .5 ft, .5 ft
pin5 =.6571 .* (.5+.5);
pcat5 = .6801 .* 12.0589;
plate5= 0;
bed5 = 80223 + ((A.*1) .* 96.76); %lbm
bedf5 = bed5 .*g;
wtp5 = bedf5 ./ Ain;

p5= pin5+pcat5+plate5+wtp5;
pd5 = pin5+pcat5+plate5;

pdropr = pd1+pd2+pd3+pd4+pd5;












